let ourin = alert("              Regras do jogo:\n 1) Digite números para suas respostas\n 2) Esteja ciente sobre suas respostas, pense bem!\n 3) Você tem 20 pontos de vida, cuidado com suas respostas! \n\nOlá Muna Dahouk, vamos relembrar um pouco sobre sua história: \nBom, tudo começou quando você se tornou uma refugiada síria que ganhou destaque por sua jornada inspiradora e sua luta por um futuro melhor. Originária da Síria, você foi forçada a deixar seu país devido ao conflito armado e à violência generalizada. Após escapar da guerra, você e sua família passaram por uma difícil jornada em busca de segurança. Vocês passaram um tempo em campos de refugiados, enfrentando condições adversas e lutando para sobreviver. Durante esse período, você se dedicou a melhorar sua educação e a ajudar outras pessoas ao seu redor, apesar das circunstâncias desafiadoras. Sua história é um exemplo de resiliência e determinação diante da adversidade, refletindo a luta e a esperança de muitos refugiados ao redor do mundo. Vamos parar de falar sobre sua história e vamos direto ao ponto, bom, primeiramente você começou em uma situação não muito boa, o que quer fazer agora? \nClique em Ok para continuar");
let pergunta1 = Number(prompt(" \nVocê acabou de acordar muito cansada, está meio gripada, e com muita preguiça!\n\n1- Ir treinar mesmo estando mal \n\n2- Ficar em casa descansando?"))
let pontosvida = 20
let soma = 5

switch(pergunta1){
    case 1: 
        alert("Ótima escolha, agora você tem 4 opções de comidas, o que você quer comer antes de ir treinar?");
        break
    case 2: 
        let resultado = pontosvida-soma
        alert("Que pena você perdeu 5 pontos de vida, agora você tem " + resultado + " pontos sobrando!")
        break
}



